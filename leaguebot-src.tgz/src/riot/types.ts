// Subset of Riot DTOs we use. Field names match the API exactly.

export interface AccountDto {
  puuid: string;
  gameName?: string;
  tagLine?: string;
}

export type RankedQueueType = 'RANKED_SOLO_5x5' | 'RANKED_FLEX_SR' | (string & {});

export interface LeagueEntryDto {
  leagueId?: string;
  puuid: string;
  queueType: RankedQueueType;
  tier: string; // IRON..CHALLENGER
  rank: string; // I..IV
  leaguePoints: number;
  wins: number;
  losses: number;
  hotStreak: boolean;
  veteran: boolean;
  freshBlood: boolean;
  inactive: boolean;
  miniSeries?: { losses: number; progress: string; target: number; wins: number };
}

export interface ParticipantDto {
  puuid: string;
  riotIdGameName?: string;
  riotIdTagline?: string;
  summonerName?: string;
  championName: string;
  championId: number;
  champLevel: number;
  teamId: 100 | 200;
  teamPosition: string; // TOP JUNGLE MIDDLE BOTTOM UTILITY or ''
  individualPosition: string;
  win: boolean;
  kills: number;
  deaths: number;
  assists: number;
  totalMinionsKilled: number;
  neutralMinionsKilled: number;
  goldEarned: number;
  totalDamageDealtToChampions: number;
  visionScore: number;
  item0: number; item1: number; item2: number; item3: number; item4: number; item5: number; item6: number;
  gameEndedInEarlySurrender: boolean;
  gameEndedInSurrender: boolean;
  pentaKills: number;
  quadraKills: number;
  tripleKills: number;
  doubleKills: number;
}

export interface TeamDto {
  teamId: 100 | 200;
  win: boolean;
  objectives?: {
    baron?: { kills: number };
    dragon?: { kills: number };
    tower?: { kills: number };
    champion?: { kills: number };
  };
}

export interface MatchDto {
  metadata: { matchId: string; participants: string[] };
  info: {
    gameCreation: number;
    gameStartTimestamp: number;
    gameEndTimestamp?: number;
    gameDuration: number; // seconds (since patch 11.20)
    gameMode: string;
    gameVersion: string;
    queueId: number;
    platformId: string;
    endOfGameResult?: string;
    participants: ParticipantDto[];
    teams: TeamDto[];
  };
}

export const QUEUE_TYPE_BY_ID: Record<number, RankedQueueType> = {
  420: 'RANKED_SOLO_5x5',
  440: 'RANKED_FLEX_SR',
};

export const QUEUE_LABEL: Record<number, string> = {
  420: 'Ranked Solo/Duo',
  440: 'Ranked Flex',
  400: 'Normal Draft',
  430: 'Normal Blind',
  450: 'ARAM',
  490: 'Quickplay',
};
